/* ChromaAid – analysis screen: 32 charts computed from the stored sessions */
(function(){
const W=360,H=230;
const col=()=>{const s=getComputedStyle(document.documentElement),g=n=>s.getPropertyValue(n).trim();return{ink:g('--ink'),mute:g('--mute'),line:g('--line'),L:'#c8402f',M:'#2f8f5b',S:'#3b5bdb',Y:'#e0a82b'}};
const slug=t=>t.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
function frame(c,k,title){c.clearRect(0,0,W,H);c.fillStyle=k.ink;c.font='bold 13px "Atkinson Hyperlegible",sans-serif';c.textAlign='left';c.textBaseline='alphabetic';c.fillText(title,10,18)}
function axes(c,k,l,t,pw,ph,max,xl,yl){c.strokeStyle=k.line;c.fillStyle=k.mute;c.font='10px sans-serif';c.textAlign='right';c.lineWidth=1;
 for(let i=0;i<=4;i++){const y=t+ph-ph*i/4;c.beginPath();c.moveTo(l,y);c.lineTo(l+pw,y);c.stroke();c.fillText((max*i/4).toFixed(max<10?1:0),l-4,y+3)}
 c.textAlign='center';if(xl)c.fillText(xl,l+pw/2,H-4);if(yl){c.save();c.translate(9,t+ph/2);c.rotate(-Math.PI/2);c.fillText(yl,0,0);c.restore()}}
function legend(c,k,series){c.font='10px sans-serif';let x=W-10;c.textAlign='right';[...series].reverse().forEach(s=>{const w=c.measureText(s.n).width;c.fillStyle=k.mute;c.fillText(s.n,x,16);c.fillStyle=s.c;c.fillRect(x-w-13,8,9,9);x-=w+22})}
function bars(c,k,title,labels,series,ymax,yl){frame(c,k,title);const l=40,r=10,t=32,b=38,pw=W-l-r,ph=H-t-b,max=ymax||Math.max(1,...series.flatMap(s=>s.v))*1.2;axes(c,k,l,t,pw,ph,max,'',yl);
 const gw=pw/labels.length,bw=gw*.72/series.length;c.font='10px sans-serif';
 labels.forEach((lb,gi)=>{series.forEach((s,si)=>{const x=l+gi*gw+gw*.14+si*bw,h=ph*s.v[gi]/max;c.fillStyle=s.c;c.fillRect(x,t+ph-h,bw-1,h);if(labels.length<=7){c.fillStyle=k.ink;c.textAlign='center';c.fillText(+s.v[gi].toFixed(1),x+bw/2,t+ph-h-3)}});c.fillStyle=k.mute;c.textAlign='center';c.fillText(lb,l+gi*gw+gw/2,t+ph+14)});
 if(series.length>1)legend(c,k,series)}
function scatter(c,k,title,pts,xl,yl,xmax,ymax,color){frame(c,k,title);const l=40,r=12,t=32,b=38,pw=W-l-r,ph=H-t-b;axes(c,k,l,t,pw,ph,ymax,xl,yl);
 c.fillStyle=k.mute;c.textAlign='center';c.font='10px sans-serif';for(let i=0;i<=4;i++)c.fillText((xmax*i/4).toFixed(0),l+pw*i/4,t+ph+13);
 let sd=7;const rnd=()=>(sd=(sd*9301+49297)%233280)/233280;c.globalAlpha=.55;c.fillStyle=color;
 pts.forEach(p=>{c.beginPath();c.arc(l+pw*Math.min(1,p[0]/xmax)+(rnd()-.5)*8,t+ph-ph*Math.min(1,p[1]/ymax)+(rnd()-.5)*8,3.2,0,7);c.fill()});c.globalAlpha=1}
function pie(c,k,title,labels,vals,colors){frame(c,k,title);const tot=vals.reduce((a,b)=>a+b,0)||1;let a0=-Math.PI/2;
 vals.forEach((v,i)=>{const a1=a0+v/tot*Math.PI*2;c.beginPath();c.moveTo(105,130);c.arc(105,130,80,a0,a1);c.closePath();c.fillStyle=colors[i];c.fill();c.strokeStyle=k.ink==='#eaf0f3'?'#18232b':'#fff';c.lineWidth=2;c.stroke();a0=a1});
 c.font='11px sans-serif';c.textAlign='left';labels.forEach((lb,i)=>{c.fillStyle=colors[i];c.fillRect(205,70+i*24,10,10);c.fillStyle=k.ink;c.fillText(lb+' – '+vals[i]+' ('+(vals[i]/tot*100).toFixed(0)+'%)',220,79+i*24)})}
function line(c,k,title,series,xmax,ymax,xl,yl){frame(c,k,title);const l=40,r=12,t=32,b=38,pw=W-l-r,ph=H-t-b;axes(c,k,l,t,pw,ph,ymax,xl,yl);
 c.fillStyle=k.mute;c.textAlign='center';c.font='10px sans-serif';for(let i=0;i<=4;i++)c.fillText((xmax*i/4).toFixed(0),l+pw*i/4,t+ph+13);
 series.forEach(s=>{c.strokeStyle=s.c;c.lineWidth=2;c.beginPath();s.p.forEach((p,i)=>{const x=l+pw*p[0]/xmax,y=t+ph-ph*p[1]/ymax;i?c.lineTo(x,y):c.moveTo(x,y)});c.stroke()});legend(c,k,series.map(s=>({n:s.n,c:s.c})))}
const ACC=[['<40',v=>v<40],['40-59',v=>v>=40&&v<60],['60-79',v=>v>=60&&v<80],['80-100',v=>v>=80]];
const IMP=[['<0',v=>v<0],['0',v=>v===0],['+1-15',v=>v>0&&v<=15],['+16-30',v=>v>15&&v<=30],['+31-45',v=>v>30&&v<=45],['>45',v=>v>45]];
const RT=[['<15',v=>v<15],['15-19',v=>v>=15&&v<20],['20-24',v=>v>=20&&v<25],['25-29',v=>v>=25&&v<30],['30+',v=>v>=30]];
const cnt=(vals,B)=>B.map(b=>vals.filter(b[1]).length);
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const med=a=>{if(!a.length)return 0;const s=[...a].sort((x,y)=>x-y),m=s.length>>1;return s.length%2?s[m]:(s[m-1]+s[m])/2};
const TN={prot:'Protanomaly',deut:'Deuteranomaly',trit:'Tritanomaly'};
function build(rows,k){
 const out=[],by=t=>rows.filter(r=>r.type===t),imp=r=>r.aided-r.unaided,K=Object.keys(TN),tc={prot:k.L,deut:k.M,trit:k.S};
 const add=(scope,t,cap,fn)=>out.push({scope,t,cap,fn});
 const hist=(scope,t,rs,key,B,color,yl)=>add(scope,t,'Number of sessions per band',(c)=>bars(c,k,t,B.map(b=>b[0]),[{n:'Sessions',c:color,v:cnt(rs.map(key),B)}],0,yl||'sessions'));
 add('all','Sessions by profile','Share of stored sessions',c=>pie(c,k,'Sessions by profile',K.map(x=>TN[x]),K.map(x=>by(x).length),[k.L,k.M,k.S]));
 add('all','Mean accuracy by profile','Unaided vs aided (%)',c=>bars(c,k,'Mean accuracy by profile',K.map(x=>TN[x]),[{n:'Unaided',c:k.L,v:K.map(x=>mean(by(x).map(r=>r.unaided)))},{n:'Aided',c:k.M,v:K.map(x=>mean(by(x).map(r=>r.aided)))}],100,'accuracy %'));
 hist('all','Unaided accuracy distribution',rows,r=>r.unaided,ACC,k.L);
 hist('all','Aided accuracy distribution',rows,r=>r.aided,ACC,k.M);
 hist('all','Improvement distribution',rows,imp,IMP,k.S);
 add('all','Unaided vs aided accuracy','Each dot is one session',c=>scatter(c,k,'Unaided vs aided accuracy',rows.map(r=>[r.unaided,r.aided]),'unaided %','aided %',100,100,k.S));
 add('all','Accuracy ranked by session','Sessions sorted low to high',c=>{const f=(key)=>[...rows.map(r=>r[key])].sort((a,b)=>a-b).map((v,i,a)=>[i/(Math.max(1,a.length-1))*100,v]);line(c,k,'Accuracy ranked by session',[{n:'Unaided',c:k.L,p:f('unaided')},{n:'Aided',c:k.M,p:f('aided')}],100,100,'session percentile','accuracy %')});
 add('all','Helpfulness rating','1 = not helpful, 5 = very helpful',c=>bars(c,k,'Helpfulness rating',['1','2','3','4','5'],[{n:'Sessions',c:k.Y,v:[1,2,3,4,5].map(n=>rows.filter(r=>r.rating===n).length)}],0,'sessions'));
 hist('all','Response time, unaided',rows.filter(r=>r.rtA),r=>r.rtA,RT,k.L,'sessions');
 hist('all','Response time, aided',rows.filter(r=>r.rtB),r=>r.rtB,RT,k.M,'sessions');
 add('all','Mean response time by profile','Seconds for 8 tasks',c=>bars(c,k,'Mean response time by profile',K.map(x=>TN[x]),[{n:'Unaided',c:k.L,v:K.map(x=>mean(by(x).filter(r=>r.rtA).map(r=>r.rtA)))},{n:'Aided',c:k.M,v:K.map(x=>mean(by(x).filter(r=>r.rtB).map(r=>r.rtB)))}],0,'seconds'));
 add('all','Improved, unchanged or worse','Aided compared with unaided',c=>pie(c,k,'Improved, unchanged or worse',['Improved','Unchanged','Worse'],[rows.filter(r=>imp(r)>0).length,rows.filter(r=>imp(r)===0).length,rows.filter(r=>imp(r)<0).length],[k.M,k.Y,k.L]));
 K.forEach(t=>{const rs=by(t),n=TN[t];
  hist(t,n+': unaided accuracy',rs,r=>r.unaided,ACC,k.L);hist(t,n+': aided accuracy',rs,r=>r.aided,ACC,k.M);hist(t,n+': improvement',rs,imp,IMP,tc[t]);
  add(t,n+': unaided vs aided','Each dot is one session',c=>scatter(c,k,n+': unaided vs aided',rs.map(r=>[r.unaided,r.aided]),'unaided %','aided %',100,100,tc[t]));
  add(t,n+' vs all profiles','Mean accuracy (%)',c=>bars(c,k,n+' vs all profiles',['Unaided','Aided'],[{n:n,c:tc[t],v:[mean(rs.map(r=>r.unaided)),mean(rs.map(r=>r.aided))]},{n:'All',c:k.mute,v:[mean(rows.map(r=>r.unaided)),mean(rows.map(r=>r.aided))]}],100,'accuracy %'))});
 add('extra','Sessions scoring 75% or more','Share of sessions by profile',c=>bars(c,k,'Sessions scoring 75% or more',K.map(x=>TN[x]),[{n:'Unaided',c:k.L,v:K.map(x=>by(x).length?by(x).filter(r=>r.unaided>=75).length/by(x).length*100:0)},{n:'Aided',c:k.M,v:K.map(x=>by(x).length?by(x).filter(r=>r.aided>=75).length/by(x).length*100:0)}],100,'% of sessions'));
 add('extra','Improvement vs aided response time','Do faster answers improve more?',c=>scatter(c,k,'Improvement vs aided time',rows.filter(r=>r.rtB).map(r=>[r.rtB,Math.max(0,imp(r))]),'aided time (s)','improvement (points)',30,60,k.S));
 add('extra','Mean improvement by rating','Points gained, grouped by rating',c=>bars(c,k,'Mean improvement by rating',['1','2','3','4','5'],[{n:'Points',c:k.M,v:[1,2,3,4,5].map(n=>mean(rows.filter(r=>r.rating===n).map(imp)))}],0,'points'));
 add('extra','Cumulative accuracy','Share of sessions at or below a score',c=>{const f=key=>[0,12.5,25,37.5,50,62.5,75,87.5,100].map(x=>[x,rows.length?rows.filter(r=>r[key]<=x).length/rows.length*100:0]);line(c,k,'Cumulative accuracy',[{n:'Unaided',c:k.L,p:f('unaided')},{n:'Aided',c:k.M,p:f('aided')}],100,100,'accuracy %','% of sessions')});
 add('extra','Median improvement by profile','Points gained',c=>bars(c,k,'Median improvement by profile',K.map(x=>TN[x]),[{n:'Median',c:k.S,v:K.map(x=>med(by(x).map(imp)))}],0,'points'));
 return out}
function dl(cv,t){const a=document.createElement('a');a.href=cv.toDataURL('image/png');a.download=slug(t)+'.png';a.click()}
window.renderAnalysis=async function(){const rows=(await dbAll('sessions')).filter(r=>isFinite(r.unaided)&&isFinite(r.aided)),box=document.getElementById('charts'),sc=document.getElementById('aScope').value,k=col();
 if(!rows.length){box.innerHTML='<div class="card"><p>No sessions stored yet. Take the test or load sessions to see the analysis.</p><button class="btn" id="aLoad">Load 100 simulated sessions</button></div>';document.getElementById('aLoad').onclick=async()=>{document.getElementById('demo').click();setTimeout(renderAnalysis,2500)};document.getElementById('aNote').textContent='';return}
 const src=s=>rows.filter(r=>r.source===s).length;document.getElementById('aNote').textContent=`Computed from ${rows.length} stored sessions (${src('simulated')} simulated, ${src('imported')} imported, ${src('live')} live). Click a chart to download it as PNG.`;
 const list=build(rows,k).filter(d=>sc==='full'||(sc==='all'?d.scope==='all':d.scope===sc));
 box.innerHTML='';list.forEach(d=>{const w=document.createElement('div');w.className='chart';const cv=document.createElement('canvas');cv.width=W*2;cv.height=H*2;cv.style.aspectRatio=W+'/'+H;cv.title='Click to download PNG';cv.dataset.title=d.t;const c=cv.getContext('2d');c.scale(2,2);d.fn(c);cv.onclick=()=>dl(cv,d.t);cv.setAttribute('role','img');cv.setAttribute('aria-label',d.t);w.appendChild(cv);const p=document.createElement('div');p.className='cap';p.textContent=d.cap;w.appendChild(p);box.appendChild(w)})};
document.getElementById('aScope').onchange=()=>renderAnalysis();
document.getElementById('aAll').onclick=()=>{[...document.querySelectorAll('#charts canvas')].forEach((cv,i)=>setTimeout(()=>dl(cv,cv.dataset.title),i*180))};
})();
