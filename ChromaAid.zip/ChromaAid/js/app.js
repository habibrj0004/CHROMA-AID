const $=id=>document.getElementById(id);
const M={prot:[[.152286,1.052583,-.204868],[.114503,.786281,.099216],[-.003882,-.048116,1.051998]],
deut:[[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.01182,.04294,.968881]],
trit:[[1.255528,-.076749,-.178779],[-.078411,.930809,.147602],[.004733,.691367,.3039]]};
const E={prot:[[0,0,0],[.7,1,0],[.7,0,1]],deut:[[0,0,0],[.7,1,0],[.7,0,1]],trit:[[1,0,.7],[0,1,.7],[0,0,0]]};
const TYPES={prot:'Protanomaly',deut:'Deuteranomaly',trit:'Tritanomaly'};
const FAM=['red','orange','yellow','green','blue','purple','brown','neutral'];
const SYM={red:'●',orange:'▲',yellow:'■',green:'◆',blue:'✚',purple:'★',brown:'▼',neutral:''};
const NAMES=[['Red','FF0000','red'],['Dark red','8B0000','red'],['Crimson','DC143C','red'],['Maroon','800000','red'],['Salmon','FA8072','red'],['Orange','FFA500','orange'],['Gold','FFD700','yellow'],['Yellow','FFFF00','yellow'],['Khaki','BDB76B','yellow'],['Olive','808000','green'],['Lime','00FF00','green'],['Green','008000','green'],['Dark green','006400','green'],['Teal','008080','green'],['Turquoise','40E0D0','blue'],['Cyan','00FFFF','blue'],['Sky blue','87CEEB','blue'],['Blue','0000FF','blue'],['Navy','000080','blue'],['Purple','800080','purple'],['Violet','EE82EE','purple'],['Magenta','FF00FF','purple'],['Lavender','E6E6FA','purple'],['Pink','FFC0CB','purple'],['Brown','8B4513','brown'],['Tan','D2B48C','brown'],['Beige','F5F5DC','neutral'],['Grey','808080','neutral'],['White','FFFFFF','neutral'],['Black','000000','neutral']];
const hex2rgb=h=>[0,2,4].map(i=>parseInt(h.slice(i,i+2),16));
const rgb2hex=(r,g,b)=>'#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();
function nameOf(r,g,b){let best,bd=1e9;for(const n of NAMES){const [a,c,d]=hex2rgb(n[1]);const rm=(r+a)/2;const dist=(2+rm/256)*(r-a)**2+4*(g-c)**2+(2+(255-rm)/256)*(b-d)**2;if(dist<bd){bd=dist;best=n}}return {name:best[0],fam:best[2]}}
function adjustPx(r,g,b,type,k,contrast){const m=M[type],I=[[1,0,0],[0,1,0],[0,0,1]],v=[r,g,b];
 const s=[0,1,2].map(i=>[0,1,2].reduce((a,j)=>a+((1-k)*I[i][j]+k*m[i][j])*v[j],0));
 const er=[r-s[0],g-s[1],b-s[2]],sh=E[type].map(row=>row[0]*er[0]+row[1]*er[1]+row[2]*er[2]);
 return [r+sh[0],g+sh[1],b+sh[2]].map(x=>{if(contrast)x=(x-128)*1.25+128;return Math.max(0,Math.min(255,Math.round(x)))})}
// ---------- database (IndexedDB) ----------
let db;const dbOpen=()=>new Promise((res,rej)=>{const q=indexedDB.open('chromaaid',1);q.onupgradeneeded=()=>{q.result.createObjectStore('prefs');q.result.createObjectStore('sessions',{autoIncrement:true})};q.onsuccess=()=>{db=q.result;res()};q.onerror=()=>rej(q.error)});
const tx=(s,m,f)=>new Promise((res,rej)=>{const t=db.transaction(s,m),o=t.objectStore(s),r=f(o);t.oncomplete=()=>res(r&&r.result);t.onerror=()=>rej(t.error)});
const dbPut=(s,v,k)=>tx(s,'readwrite',o=>o.put(v,k)),dbAdd=(s,v)=>tx(s,'readwrite',o=>o.add(v)),dbGet=(s,k)=>tx(s,'readonly',o=>o.get(k)),dbAll=s=>tx(s,'readonly',o=>o.getAll()),dbClear=s=>tx(s,'readwrite',o=>o.clear());
function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',2200)}
// ---------- state ----------
let prefs={name:'',type:'deut',intensity:70,correction:true,contrast:false,symbols:true};
function show(s){document.querySelectorAll('section').forEach(e=>e.classList.toggle('on',e.id===s));document.querySelectorAll('nav button').forEach(b=>b.toggleAttribute('aria-current',b.dataset.s===s)&&(b.dataset.s===s?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current')));if(s==='test')refreshResults();if(s==='img')syncImgBox()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>show(b.dataset.s));
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>show(b.dataset.go));
function loadPrefsUI(){$('pName').value=prefs.name;$('pType').value=prefs.type;$('pInt').value=prefs.intensity;$('pIntV').textContent=prefs.intensity;$('pCor').checked=prefs.correction;$('pCon').checked=prefs.contrast;$('pSym').checked=prefs.symbols;dashboard()}
$('pInt').oninput=()=>$('pIntV').textContent=$('pInt').value;
$('savePrefs').onclick=async()=>{prefs={name:$('pName').value.trim(),type:$('pType').value,intensity:+$('pInt').value,correction:$('pCor').checked,contrast:$('pCon').checked,symbols:$('pSym').checked};await dbPut('prefs',prefs,'user');dashboard();toast('Preferences saved')};
$('resetPrefs').onclick=()=>{prefs={name:'',type:'deut',intensity:70,correction:true,contrast:false,symbols:true};loadPrefsUI();toast('Defaults restored – save to keep them')};
function dashboard(){$('dashProfile').textContent=(prefs.name?prefs.name+' – ':'')+TYPES[prefs.type]+', intensity '+prefs.intensity+'%';
 const cols=['#C8402F','#2F8F5B','#8B5A2B','#E0862B','#808000','#B0B0B0','#7A3B8F','#3B5BDB'];
 $('stripO').innerHTML=cols.map(c=>`<div style="background:${c}"></div>`).join('');
 $('stripA').innerHTML=cols.map(c=>{const a=adjustPx(...hex2rgb(c.slice(1)),prefs.type,prefs.intensity/100,prefs.contrast);const f=nameOf(...hex2rgb(c.slice(1))).fam;return `<div style="background:${prefs.correction?rgb2hex(...a):c};display:flex;align-items:center;justify-content:center;font-size:1.6rem;color:#fff;text-shadow:0 0 3px #000">${prefs.symbols?SYM[f]:''}</div>`}).join('')}
// ---------- image assistance ----------
const cO=$('cO'),cA=$('cA'),xO=cO.getContext('2d',{willReadFrequently:true}),xA=cA.getContext('2d');
function syncImgBox(){$('iCor').checked=prefs.correction;$('iCon').checked=prefs.contrast;$('iSym').checked=prefs.symbols;if(!cO.width||cO.width===300)sampleImg()}
function render(){if(!cO.width)return;const d=xO.getImageData(0,0,cO.width,cO.height),o=xA.createImageData(d),k=prefs.intensity/100,cor=$('iCor').checked,con=$('iCon').checked;
 for(let i=0;i<d.data.length;i+=4){let r=d.data[i],g=d.data[i+1],b=d.data[i+2];let a=[r,g,b];if(cor)a=adjustPx(r,g,b,prefs.type,k,con);else if(con)a=a.map(x=>Math.max(0,Math.min(255,(x-128)*1.25+128)));o.data[i]=a[0];o.data[i+1]=a[1];o.data[i+2]=a[2];o.data[i+3]=255}
 xA.putImageData(o,0,0);
 if($('iSym').checked){const st=28;xA.font='bold 16px sans-serif';xA.textAlign='center';xA.textBaseline='middle';
  for(let y=st/2;y<cO.height;y+=st)for(let x=st/2;x<cO.width;x+=st){const p=xO.getImageData(x|0,y|0,1,1).data,f=nameOf(p[0],p[1],p[2]).fam;if(f==='neutral')continue;xA.lineWidth=3;xA.strokeStyle='#000';xA.strokeText(SYM[f],x,y);xA.fillStyle='#fff';xA.fillText(SYM[f],x,y)}}}
function loadImage(src){const im=new Image();im.onload=()=>{const s=Math.min(1,640/im.width);cO.width=cA.width=Math.round(im.width*s);cO.height=cA.height=Math.round(im.height*s);xO.drawImage(im,0,0,cO.width,cO.height);render()};im.src=src}
$('file').onchange=e=>{const f=e.target.files[0];if(f)loadImage(URL.createObjectURL(f))};
function sampleImg(){cO.width=cA.width=480;cO.height=cA.height=300;const c=xO;c.fillStyle='#e8e2d0';c.fillRect(0,0,480,300);
 const items=[['#C8402F',70,70],['#2F8F5B',190,70],['#8B5A2B',310,70],['#E0862B',420,70],['#808000',70,190],['#B0B0B0',190,190],['#7A3B8F',310,190],['#3B5BDB',420,190]];
 items.forEach(([col,x,y])=>{c.fillStyle=col;c.beginPath();c.arc(x,y,48,0,7);c.fill()});render()}
$('sample').onclick=sampleImg;['iCor','iCon','iSym'].forEach(i=>$(i).onchange=render);
$('dl').onclick=()=>{const a=document.createElement('a');a.href=cA.toDataURL('image/png');a.download='chromaaid-adjusted.png';a.click();toast('Adjusted image downloaded')};
function pick(e){const c=e.target,r=c.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)*c.width/r.width),y=Math.floor((e.clientY-r.top)*c.height/r.height),p=xO.getImageData(x,y,1,1).data;identify(p[0],p[1],p[2]);show('id')}
cO.onclick=cA.onclick=pick;
// ---------- identifier ----------
function identify(r,g,b){const n=nameOf(r,g,b),a=adjustPx(r,g,b,prefs.type,prefs.intensity/100,prefs.contrast);
 $('idSw').style.background=rgb2hex(r,g,b);$('idSw').className='sw p-'+n.fam;$('idSw').textContent=SYM[n.fam];
 $('idName').textContent=n.name+(SYM[n.fam]?'  '+SYM[n.fam]:'');$('idHex').textContent='HEX '+rgb2hex(r,g,b);$('idRgb').textContent=`RGB ${r}, ${g}, ${b}`;$('idAdj').textContent='Adjusted for your profile: '+rgb2hex(...a)}
$('idPick').oninput=e=>identify(...hex2rgb(e.target.value.slice(1)));
// ---------- test ----------
const POOL=['Red','Green','Brown','Orange','Olive','Pink','Grey','Purple','Blue','Teal','Lime','Magenta'];
const GROUPS=[['Red','Green','Brown','Orange','Olive','Lime'],['Pink','Grey','Purple','Magenta'],['Blue','Teal','Purple']];
const shuffle=a=>a.map(v=>[Math.random(),v]).sort((x,y)=>x[0]-y[0]).map(v=>v[1]);
function makeTasks(){return shuffle(POOL).slice(0,8).map(t=>{const g=GROUPS.find(g=>g.includes(t))||POOL;let d=shuffle(g.filter(x=>x!==t));d=d.concat(shuffle(POOL.filter(x=>x!==t&&!d.includes(x)))).slice(0,3);return {t,opts:shuffle([t,...d])}})}
let T=null;
function tIntro(){$('tBox').innerHTML=`<p>Eight tasks, shown twice: first <b>without assistance</b>, then <b>with assistance</b> (adjusted colour, symbol and pattern). Choose the name of each swatch.</p><button class="btn" id="tStart">Start test</button>`;$('tStart').onclick=()=>{T={tasks:makeTasks(),phase:'A',i:0,a:[],b:[],t0:Date.now(),ta:0,tb:0};tShow()}}
function tShow(){const p=T.phase,list=p==='A'?T.tasks:T.order,item=list[T.i],nm=NAMES.find(n=>n[0]===item.t),rgb=hex2rgb(nm[1]);
 let col=rgb2hex(...rgb),cls='',sym='';if(p==='B'){col=rgb2hex(...adjustPx(...rgb,prefs.type,prefs.intensity/100,prefs.contrast));cls='p-'+nm[2];sym=SYM[nm[2]]}
 $('tBox').innerHTML=`<p class="small">${p==='A'?'Round 1 – no assistance':'Round 2 – with assistance'} · task ${T.i+1} of ${list.length}</p><div class="row"><div class="sw ${cls}" style="background:${col}" aria-label="Colour swatch">${sym}</div>
 <div class="opts">${item.opts.map(o=>`<button class="btn alt" data-o="${o}">${o}</button>`).join('')}</div></div>${p==='B'?'<p class="small">Symbol key: ● red ▲ orange ■ yellow ◆ green ✚ blue ★ purple ▼ brown</p>':''}`;
 document.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>{(p==='A'?T.a:T.b).push(b.dataset.o===item.t);T.i++;if(T.i<list.length)return tShow();
  if(p==='A'){T.ta=(Date.now()-T.t0)/1000;T.order=shuffle(T.tasks);T.phase='B';T.i=0;T.t0=Date.now();tShow()}else{T.tb=(Date.now()-T.t0)/1000;tDone()}})}
async function tDone(){const n=8,ua=T.a.filter(Boolean).length/n*100,ai=T.b.filter(Boolean).length/n*100;
 $('tBox').innerHTML=`<h2>Your result</h2><p>Without assistance: <b>${ua}%</b> · With assistance: <b>${ai}%</b> (${ai-ua>=0?'+':''}${(ai-ua).toFixed(0)} points)</p><label for="fb">How helpful was the assistance?</label><select id="fb"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select>
 <div class="row"><button class="btn" id="fbSave">Save result</button><button class="btn alt" id="again">Retake</button></div>`;
 $('fbSave').onclick=async()=>{await dbAdd('sessions',{participant:prefs.name||'You',type:prefs.type,unaided:ua,aided:ai,rtA:+T.ta.toFixed(1),rtB:+T.tb.toFixed(1),rating:+$('fb').value,source:'live',ts:Date.now()});toast('Result saved to database');tIntro();refreshResults()};$('again').onclick=tIntro}
// ---------- results ----------
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
async function refreshResults(){const rows=await dbAll('sessions');$('nRec').textContent=rows.length;
 const ua=avg(rows.map(r=>r.unaided)),ai=avg(rows.map(r=>r.aided));
 $('cmp').innerHTML=rows.length?`<div>Average without assistance</div><div class="bar"><span style="width:${ua}%;background:var(--L)">${ua.toFixed(1)}%</span></div><div>Average with assistance</div><div class="bar"><span style="width:${ai}%;background:var(--M)">${ai.toFixed(1)}%</span></div><p>Mean improvement: <b>${(ai-ua).toFixed(1)} points</b> across ${rows.length} sessions.</p>`:'<p class="small">No results yet. Take the test or load sessions below.</p>';
 $('sum').innerHTML=Object.keys(TYPES).map(k=>{const s=rows.filter(r=>r.type===k);return s.length?`<p class="small">${TYPES[k]}: ${s.length} sessions, ${avg(s.map(r=>r.unaided)).toFixed(1)}% → ${avg(s.map(r=>r.aided)).toFixed(1)}%</p>`:''}).join('');
 $('tbl').innerHTML='<tr><th>#</th><th>Participant</th><th>Type</th><th>Unaided</th><th>Aided</th><th>Source</th></tr>'+rows.slice(-100).reverse().map((r,i)=>`<tr><td>${rows.length-i}</td><td>${r.participant}</td><td>${TYPES[r.type]||r.type}</td><td>${(+r.unaided).toFixed(0)}%</td><td>${(+r.aided).toFixed(0)}%</td><td>${r.source}</td></tr>`).join('')}
$('demo').onclick=async()=>{const w=['prot','deut','deut','deut','trit','prot'];for(let i=1;i<=100;i++){const u=Math.max(25,Math.min(100,Math.round((60+Math.random()*30-10)/12.5)*12.5)),a=Math.min(100,Math.round((u+8+Math.random()*30)/12.5)*12.5);await dbAdd('sessions',{participant:'P'+String(i).padStart(3,'0'),type:w[Math.floor(Math.random()*w.length)],unaided:u,aided:a,rtA:+(12+Math.random()*20).toFixed(1),rtB:+(10+Math.random()*16).toFixed(1),rating:3+Math.floor(Math.random()*3),source:'simulated',ts:Date.now()})}toast('100 simulated sessions added');refreshResults()};
$('csv').onchange=async e=>{const f=e.target.files[0];if(!f)return;const lines=(await f.text()).trim().split(/\r?\n/).slice(1);let n=0;for(const l of lines){const c=l.split(',');if(c.length<4||isNaN(c[2])||isNaN(c[3]))continue;const t=/^p/i.test(c[1])?'prot':/^t/i.test(c[1])?'trit':'deut';await dbAdd('sessions',{participant:c[0],type:t,unaided:+c[2],aided:+c[3],source:'imported',ts:Date.now()});n++}toast(n+' rows imported');refreshResults()};
$('exp').onclick=async()=>{const rows=await dbAll('sessions');const t='participant,type,unaided,aided,source\n'+rows.map(r=>[r.participant,r.type,r.unaided,r.aided,r.source].join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv'}));a.download='chromaaid-results.csv';a.click()};
$('clr').onclick=async()=>{if(confirm('Delete all stored results?')){await dbClear('sessions');refreshResults()}};
// ---------- automated tests ----------
$('runQA').onclick=async()=>{const R=[];const t=(id,desc,f)=>Promise.resolve().then(f).then(ok=>R.push([id,desc,!!ok]),()=>R.push([id,desc,false]));
 await t('TC01','FF0000 is named Red',()=>nameOf(255,0,0).name==='Red');
 await t('TC02','HEX conversion round-trips',()=>rgb2hex(...hex2rgb('3B5BDB'))==='#3B5BDB');
 await t('TC03','Zero intensity leaves colour unchanged',()=>adjustPx(200,60,40,'prot',0,false).join()==='200,60,40');
 await t('TC04','Correction changes a red/green pair for deuteranomaly',()=>adjustPx(200,60,40,'deut',1,false).join()!=='200,60,40');
 await t('TC05','Output stays within 0-255',()=>adjustPx(255,0,255,'trit',1,true).every(v=>v>=0&&v<=255));
 await t('TC06','Neutral grey has no symbol',()=>SYM[nameOf(128,128,128).fam]==='');
 await t('TC07','Preferences save and reload',async()=>{await dbPut('prefs',prefs,'user');return (await dbGet('prefs','user')).type===prefs.type});
 await t('TC08','Database accepts and removes a session',async()=>{const b=(await dbAll('sessions')).length;await dbAdd('sessions',{participant:'QA',type:'deut',unaided:50,aided:75,source:'qa',ts:0});const m=(await dbAll('sessions')).length===b+1;const all=(await dbAll('sessions')).filter(r=>r.source!=='qa');await dbClear('sessions');for(const r of all)await dbAdd('sessions',r);return m});
 await t('TC09','Test generator makes 8 tasks with 4 options each',()=>{const k=makeTasks();return k.length===8&&k.every(x=>x.opts.length===4&&x.opts.includes(x.t))});
 await t('TC10','Adjusted canvas exports PNG',()=>cA.toDataURL('image/png').startsWith('data:image/png'));
 $('qaT').innerHTML='<tr><th>ID</th><th>Test</th><th>Result</th></tr>'+R.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td class="${r[2]?'pass':'fail'}">${r[2]?'Pass':'Fail'}</td></tr>`).join('')+`<tr><td colspan="3"><b>${R.filter(r=>r[2]).length} of ${R.length} passed</b></td></tr>`};
// ---------- start ----------
(async()=>{await dbOpen();const p=await dbGet('prefs','user');if(p)prefs=p;loadPrefsUI();tIntro();show('dash')})();
