/* ChromaAid – shell behaviour: 3-dot menu, search, theme, dashboard stats */
(function(){
const q=document.getElementById('q'),menu=document.getElementById('menu'),dots=document.getElementById('dots');
const SCR={dash:'dashboard home welcome start',prefs:'personalisation settings profile preferences protanomaly deuteranomaly tritanomaly intensity',img:'image upload adjusted original download photo',id:'colour color identifier name hex rgb pick',test:'test results accuracy database sessions csv import export',analysis:'analysis charts graphs statistics histogram scatter',qa:'quality checks testing unit tests'};
const _show=show;show=function(s){_show(s);if(s==='dash')dashStats();if(s==='analysis')renderAnalysis();window.scrollTo(0,0)};
const _dash=dashboard;dashboard=function(){_dash();side()};
function side(){document.getElementById('sfName').textContent=prefs.name||'Guest';document.getElementById('sfType').textContent=TYPES[prefs.type]+' · '+prefs.intensity+'%';document.getElementById('pillT').textContent=TYPES[prefs.type]}
async function dashStats(){const r=(await dbAll('sessions')).filter(x=>isFinite(x.unaided)),u=avg(r.map(x=>x.unaided)),a=avg(r.map(x=>x.aided));
 document.getElementById('stats').innerHTML=[[r.length,'sessions stored'],[r.length?u.toFixed(0)+'%':'–','average without assistance'],[r.length?a.toFixed(0)+'%':'–','average with assistance'],[r.length?'+'+(a-u).toFixed(1):'–','points gained'],[TYPES[prefs.type],'your profile']].map(s=>`<div class="stat"><b>${s[0]}</b><span>${s[1]}</span></div>`).join('')}
// 3-dot menu
const close=()=>{menu.classList.remove('on');dots.setAttribute('aria-expanded','false')};
dots.onclick=e=>{e.stopPropagation();const o=menu.classList.toggle('on');dots.setAttribute('aria-expanded',o)};
document.addEventListener('click',close);document.addEventListener('keydown',e=>{if(e.key==='Escape')close();if(e.key==='/'&&document.activeElement.tagName!=='INPUT'){e.preventDefault();q.focus()}});
menu.onclick=e=>{const m=e.target.dataset.m;if(!m)return;close();
 if(m==='theme'){const d=document.documentElement,dark=getComputedStyle(d).getPropertyValue('--paper').trim()==='#10181e';d.dataset.theme=dark?'light':'dark';if(document.getElementById('analysis').classList.contains('on'))renderAnalysis()}
 if(m==='demo')document.getElementById('demo').click();if(m==='export')document.getElementById('exp').click();if(m==='shots')document.getElementById('dl').click();if(m==='clear')document.getElementById('clr').click();
 if(m==='about')alert('ChromaAid v2\nA personalised computer-based system to help people with anomalous trichromacy distinguish colours.\nData is stored locally in your browser (IndexedDB).')};
// search
q.oninput=()=>{const v=q.value.trim().toLowerCase();document.querySelectorAll('.side nav button').forEach(b=>b.classList.toggle('hide',!!v&&!(SCR[b.dataset.s]+' '+b.textContent.toLowerCase()).includes(v)));
 document.querySelectorAll('#tbl tr').forEach((r,i)=>{r.style.display=!v||i===0||r.textContent.toLowerCase().includes(v)?'':'none'})};
q.onkeydown=e=>{if(e.key!=='Enter')return;const v=q.value.trim().toLowerCase();if(!v)return;
 const hex=v.match(/^#?([0-9a-f]{6})$/),nm=NAMES.find(n=>n[0].toLowerCase()===v)||NAMES.find(n=>n[0].toLowerCase().startsWith(v));
 if(hex){identify(...hex2rgb(hex[1]));show('id');return}
 if(nm){identify(...hex2rgb(nm[1]));show('id');return}
 const s=Object.keys(SCR).find(k=>(SCR[k]+' '+k).includes(v));if(s)show(s);else toast('No match for “'+q.value+'”')};
})();
