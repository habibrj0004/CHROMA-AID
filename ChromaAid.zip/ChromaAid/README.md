# ChromaAid
A personalised computer-based system to help people with anomalous trichromacy (protanomaly, deuteranomaly, tritanomaly) distinguish colours.

## Run it (Visual Studio Code)
1. Unzip the folder and open it in VS Code (File > Open Folder).
2. Install the **Live Server** extension, right-click `index.html`, choose **Open with Live Server**.
   (Double-clicking `index.html` also works in Chrome or Edge.)
3. No Node, build step or server is needed. Data is stored in the browser database (IndexedDB).

## Structure
- `index.html` – layout: sidebar (with 3-dot menu), search bar, seven screens
- `css/style.css` – design system, light/dark themes, responsive layout
- `js/app.js` – colour engine, database, image assistance, identifier, test
- `js/analysis.js` – Analysis screen (32 charts drawn from the stored sessions)
- `js/ui.js` – 3-dot menu, search, theme, dashboard statistics
- `data/sample-sessions-SIMULATED.csv` – 100 simulated rows to try CSV import
- `docs/` – requirements traceability, test plan and user manual
- `screenshots/` – 20 screen captures and `screenshots/charts/` 32 chart images, taken from the running app

## Data honesty
The 100 sessions in the screenshots and charts are **simulated** and labelled so in the database. They are not from the Dryad or Figshare datasets. Download those datasets, convert the relevant columns to `participant,type,unaided,aided` and use **Test & results > Import CSV** to analyse real values.

## Firebase option
The database calls are in `js/app.js` (`dbPut`, `dbAdd`, `dbGet`, `dbAll`, `dbClear`). Replacing these five functions with Firestore calls moves storage to Firebase.
