# Requirements traceability
| ID | Requirement | Where it is met |
|---|---|---|
| FR01 | Select colour vision profile | Personalisation |
| FR02 | Upload an image | Image assistance |
| FR03 | Original and adjusted images | Image assistance |
| FR04 | Pixel/colour name, HEX, RGB | Colour identifier |
| FR05 | Labels, patterns, symbols | Image assistance, Colour identifier, Test |
| FR06 | Adjust assistance settings | Personalisation (intensity, toggles) |
| FR07 | Save and reload preferences | IndexedDB, tested in TC07 |
| FR08 | Colour-identification test | Test & results |
| FR09 | Compare with and without assistance | Test & results, Analysis |
| FR10 | Export adjusted image | Download button (TC10) |

# Automated tests (Quality checks screen)
TC01 name of FF0000 · TC02 HEX round trip · TC03 zero intensity unchanged · TC04 correction changes a red/green colour · TC05 output stays in 0-255 · TC06 neutral grey has no symbol · TC07 preferences save and reload · TC08 database add and restore · TC09 test generator makes 8 tasks with 4 options · TC10 PNG export.
Result in the captured run: 10 of 10 passed (screenshot 16).

# Manual test cases
| ID | Steps | Expected |
|---|---|---|
| M01 | Save each profile, open Image assistance | Adjusted image differs from original (screenshots 03-05) |
| M02 | Click an image point | Colour identifier shows name, HEX, RGB (06) |
| M03 | Search "brown" and press Enter | Identifier opens for Brown (07) |
| M04 | Open 3-dot menu | Six actions listed (09) |
| M05 | Complete both test rounds | Accuracy for both rounds shown (12) |
| M06 | Load 100 sessions | Table shows 100 rows (13) |
| M07 | Open Analysis, choose Full set | 32 charts drawn (14) |

# User manual
1. Open Personalisation, enter your name, choose a profile and intensity, press Save.
2. Open Image assistance, upload a picture or use the sample, and compare the two views. Turn symbols on to see shape cues.
3. Click any point to see its colour name and values in Colour identifier. You can also type a colour name or HEX code in the search bar and press Enter.
4. Take the test in Test & results, then save your result with a helpfulness rating.
5. Open Analysis to view charts. Click a chart to download it.
